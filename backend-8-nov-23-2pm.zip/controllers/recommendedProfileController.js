// const axios = require('axios');
// const { userLogUrl } = require('../config');

const BasicInfo = require('../model/basicInfo');
const EducationCareerInfo = require('../model/educationalCareerDetails');
const FamilyInfo = require('../model/familyInfo');
const LifestyleInfo = require('../model/lifeStyle');
const ReligiousBackground = require('../model/religiousBackground');
const mongoose = require('mongoose'); // Import Mongoose for isValidObjectId

const User = require('../model/user');
const {
    BasicDetailsPreference,
    CommunityPreferences,
    locationPreference,
    educationCareerPreference,
    OtherPreferences,
} = require('../model/preference');

const returnRecommendedProfile = async (req, res) => {
    try {
        const { userId } = req.body;

        if (!userId) {
            return res.status(400).json({ message: 'User ID is required' });
        }

        if (!mongoose.Types.ObjectId.isValid(userId)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid user ID format. Please provide a valid user ID.',
            });
        }

        // Find the user by their userId
        const user = await User.findById(userId);

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        // Collect all user preferences
        const basicDetailsPreference = await BasicDetailsPreference.findOne({ userId });
        const communityPreferences = await CommunityPreferences.findOne({ userId });
        const locationPref = await locationPreference.findOne({ userId });
        const educationCareerPreferences = await educationCareerPreference.findOne({ userId });
        const otherPreferences = await OtherPreferences.findOne({ userId });

        // Create an array to store the tables to query
        const tablesToQuery = [];

        // Create an array to store the queries for debugging
        const queries = [];

        // Based on preferences, add tables to query
        if (basicDetailsPreference) {
            tablesToQuery.push(BasicInfo);
            queries.push({ table: 'BasicInfo', query: {} });
        }

        if (communityPreferences) {
            tablesToQuery.push(ReligiousBackground, FamilyInfo);

            if (communityPreferences.religions.openToAll) {
                tablesToQuery.push(LifestyleInfo);
            }

            queries.push({ table: 'ReligiousBackground', query: {} });
            queries.push({ table: 'FamilyInfo', query: {} });

            if (communityPreferences.religions.openToAll) {
                queries.push({ table: 'LifestyleInfo', query: {} });
            }
        }

        if (locationPref) {
            tablesToQuery.push(User);
            queries.push({ table: 'User', query: {} });
        }

        if (educationCareerPreferences) {
            tablesToQuery.push(EducationCareerInfo);
            queries.push({ table: 'EducationCareerInfo', query: {} });
        }

        if (otherPreferences) {
            tablesToQuery.push(LifestyleInfo);
            queries.push({ table: 'LifestyleInfo', query: {} });
        }

        // Construct the query to find user profiles
        const selectQuery = {};
        selectQuery._id = { $ne: userId }; // Exclude the user's own profile
        selectQuery.gender = user.gender === 'Male' ? 'Female' : 'Male';

        // Create an array of promises for each table's query
        const queryPromises = tablesToQuery.map(async (table, index) => {
            // For each table, construct a query based on the preferences of the requested user
            const tableQuery = { ...selectQuery };

            if (basicDetailsPreference && basicDetailsPreference.ageRange) {
                tableQuery.age = {
                    $gte: basicDetailsPreference.ageRange.min,
                    $lte: basicDetailsPreference.ageRange.max,
                };
            }

            // Add other preference conditions based on the table

            queries[index].query = tableQuery; // Update the query for debugging

            // Execute the query and return user IDs
            const result = await table.find(tableQuery, 'userId');
            return result.map((row) => row.userId);
        });

        // Execute all query promises and flatten the result
        const results = await Promise.all(queryPromises);
        const recommendedUserIds = [].concat(...results);

        // Return the recommended user IDs along with the queries for debugging
        return res.status(200).json({
            message: 'Recommended profiles based on user preferences',
            recommendedUserIds,
            queries,
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
};


const returnRecommendedProfileWithFewCriteria = async (req, res) => {
    try {
        const { userId } = req.body;

        if (!userId) {
            return res.status(400).json({ message: 'User ID is required' });
        }

        if (!mongoose.Types.ObjectId.isValid(userId)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid user ID format. Please provide a valid user ID.',
            });
        }

        // Find the user by their userId
        const user = await User.findById(userId);

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        // Get the user's preferences from BasicDetailsPreference
        const basicDetailsPreference = await BasicDetailsPreference.findOne({ userId });
        const educationCareerPreferences = await educationCareerPreference.findOne({ userId });

        // Get the user IDs of opposite gender (e.g., 'Male' if user is 'Female')
        const oppositeGender = user.gender === 'Male' ? 'Female' : 'Male';
        const oppositeGenderUserIds = await User.find(
            { gender: oppositeGender, userType: 'User', _id: { $ne: userId } },
            '_id'
        ).distinct('_id');

        // If basicDetailsPreference not found, return only oppositeGenderUserIds
        if (!basicDetailsPreference) {
            return res.status(200).json({
                message: 'User preferences for heightRange and ageRange are not found.',
                recommendedUserIds: [],
                oppositeGenderUserIds: oppositeGenderUserIds.map((id) => id.toString()),
            });
        }

        // Continue with the rest of the code to calculate age, create the query, and find matching profiles
        const { heightRange, ageRange } = basicDetailsPreference;
        const userAge = user.dateOfBirth
            ? Math.floor((new Date() - new Date(user.dateOfBirth)) / 31556952000)
            : 0;

        const currentYear = new Date().getFullYear();
        const minBirthYear = currentYear - ageRange.max;
        const maxBirthYear = currentYear - ageRange.min;

        const selectQuery = {};
        selectQuery._id = { $ne: userId };

        selectQuery.height = {
            $gte: heightRange.min,
            $lte: heightRange.max,
        };

        selectQuery.dateOfBirth = {
            $gte: new Date(`${minBirthYear}-01-01`),
            $lte: new Date(`${maxBirthYear}-12-31`),
        };

        const matchingProfiles = await BasicInfo.find(selectQuery);

        const recommendedUserIds = matchingProfiles.map((profile) => profile.userId);

        const filteredRecommendedUserIds = recommendedUserIds.filter(
            (id) => id.toString() !== userId
        );

        return res.status(200).json({
            message: 'Recommended profiles based on user preferences',
            recommendedUserIds: filteredRecommendedUserIds,
            oppositeGenderUserIds: oppositeGenderUserIds.map((id) => id.toString()),
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
};


module.exports = {
    returnRecommendedProfile,
    returnRecommendedProfileWithFewCriteria
};