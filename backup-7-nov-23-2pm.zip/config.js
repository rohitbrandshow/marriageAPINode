// config.js
const userLogUrl = 'http://localhost:5002/api/user-log'; // Replace with your actual user log API URL

module.exports = {
    userLogUrl,
    msg91ApiKey: '248168A6ljwU97ogg5bf3914a',
    msg91TemplateId: '622b3873da72f5035b46a462',
    mandrillApiKey: 'md-1UhigoCRlDCKo9ed_nHYZw',
};
