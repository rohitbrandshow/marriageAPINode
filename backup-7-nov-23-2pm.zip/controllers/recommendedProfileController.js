// const axios = require('axios');
// const { userLogUrl } = require('../config');

const BasicInfo = require('../model/basicInfo');
const EducationCareerInfo = require('../model/educationalCareerDetails');
const FamilyInfo = require('../model/familyInfo');
const LifestyleInfo = require('../model/lifeStyle');
const ReligiousBackground = require('../model/religiousBackground');
const mongoose = require('mongoose'); // Import Mongoose for isValidObjectId

const User = require('../model/user');
const {
    BasicDetailsPreference,
    CommunityPreferences,
    locationPreference,
    educationCareerPreference,
    OtherPreferences,
} = require('../model/preference');

const returnRecommendedProfile = async (req, res) => {
    try {
        const { userId } = req.body;

        if (!userId) {
            return res.status(400).json({ message: 'User ID is required' });
        }
        
        if (!mongoose.Types.ObjectId.isValid(userId)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid user ID format. Please provide a valid user ID.',
            });
        }

        // Find the user by their userId
        const user = await User.findById(userId);

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        

        // Collect all user preferences
        const basicDetailsPreference = await BasicDetailsPreference.findOne({ userId });
        const communityPreferences = await CommunityPreferences.findOne({ userId });
        const locationPref = await locationPreference.findOne({ userId });
        const educationCareerPreferences = await educationCareerPreference.findOne({ userId });
        const otherPreferences = await OtherPreferences.findOne({ userId });

        // Create an array to store the tables to query
        const tablesToQuery = [];

        // Based on preferences, add tables to query
        if (basicDetailsPreference) {
            tablesToQuery.push(BasicInfo);
        }

        if (communityPreferences) {
            tablesToQuery.push(ReligiousBackground, FamilyInfo);

            if (communityPreferences.religions.openToAll) {
                tablesToQuery.push(LifestyleInfo);
            }
        }

        if (locationPref) {
            tablesToQuery.push(User);
        }

        if (educationCareerPreferences) {
            tablesToQuery.push(EducationCareerInfo);
        }

        if (otherPreferences) {
            tablesToQuery.push(LifestyleInfo);
        }

        // Construct the query to find user profiles
        const selectQuery = {};
        selectQuery._id = { $ne: userId }; // Exclude the user's own profile
        selectQuery.gender = user.gender === 'Male' ? 'Female' : 'Male';

        // Create an array of promises for each table's query
        const queryPromises = tablesToQuery.map(async (table) => {
            const result = await table.find(selectQuery, 'userId');
            return result.map((row) => row.userId);
        });

        // Execute all query promises and flatten the result
        const results = await Promise.all(queryPromises);
        const recommendedUserIds = [].concat(...results);

        // Return the recommended user IDs
        return res.status(200).json({
            message: 'Recommended profiles based on user preferences',
            recommendedUserIds,
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
};

module.exports = {
    returnRecommendedProfile
};
