const { generateJwtToken } = require('../utils/auth');
const User = require('../model/user');
const bcrypt = require('bcrypt');

const login = async (req, res) => {
  const { email, password } = req.body;

  try {
    // Find the user by email
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    // Check if the user's account is active and email is verified
    if (user.status !== 'active' || !user.emailVerified) {
      return res.status(403).json({ message: 'Account is not active or email is not verified' });
    }

    // Check if the provided password matches the hashed password
    if (bcrypt.compareSync(password, user.password)) {
      // You can generate a JWT token here and send it as part of the response
      const token = generateJwtToken(user);

      return res.json({ status: 'true', message: 'Login successful', token });
    } else {
      return res.status(401).json({ status: 'false', message: 'Invalid email or password' });
    }
  } catch (error) {
    console.error(error);
    return res.status(500).json({ status: 'false', message: 'Server error' });
  }
};

module.exports = {
  login,
};
