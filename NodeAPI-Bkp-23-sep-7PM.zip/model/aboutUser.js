const mongoose = require('mongoose');

const aboutYourselfSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User', // Reference to the User model
    required: true,
    unique: true, // Make userId unique
  },
  aboutText: {
    type: String, // Freeform text input.
    minlength: 50, // Minimum character count.
    maxlength: 8000, // Maximum character count.
  },
});

const AboutYourself = mongoose.model('AboutYourself', aboutYourselfSchema);

module.exports = AboutYourself;
