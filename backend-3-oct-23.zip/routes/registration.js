// routes/registration.js
const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const crypto = require('crypto');
const User = require('../model/user'); // Import your User model from the appropriate path

router.post('/', async (req, res) => {
  try {
    const { name, email, phone, gender, password } = req.body;

    // Check if any required fields are missing
    if (!name || !email || !phone || !gender || !password) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    const saltRounds = 10; // Number of salt rounds for hashing

    // Hash the password with the specified number of salt rounds
    const hashedPassword = await bcrypt.hash(password, saltRounds);

    // Generate a unique verification code (you can customize this as needed)
    const verificationCode = crypto.randomBytes(4).toString('hex');

    // Check if the email is already registered and verified
    let existingVerifiedEmail = await User.findOne({ email, emailVerified: true });
    if (existingVerifiedEmail) {
      return res.status(400).json({ error: 'Email already exists' });
    }

    // Check if the phone number is already registered and verified
    let existingVerifiedPhone = await User.findOne({ phone, mobileVerified: true });
    if (existingVerifiedPhone) {
      return res.status(400).json({ error: 'Mobile number already exists' });
    }

    // Check if the email is already registered and not verified
    let existingUnverifiedEmail = await User.findOne({ email, emailVerified: false });
    if (existingUnverifiedEmail) {
      // Update the existing unverified user's information
      existingUnverifiedEmail.name = name;
      existingUnverifiedEmail.gender = gender;
      existingUnverifiedEmail.password = hashedPassword;

      // Check if the same phone number also exists in unverified email
      const existingUnverifiedPhone = await User.findOne({ phone: existingUnverifiedEmail.phone });
      if (existingUnverifiedPhone) {
        existingUnverifiedPhone.name = name;
        existingUnverifiedPhone.gender = gender;
        existingUnverifiedPhone.password = hashedPassword;
        await existingUnverifiedPhone.save();
      }

      await existingUnverifiedEmail.save();
      return res.status(200).json({ success: true, message: 'Registration successful' });
    }

    // Check if the phone number is already registered and not verified
    let existingUnverifiedPhone = await User.findOne({ phone, mobileVerified: false });
    if (existingUnverifiedPhone) {
      // Update the existing unverified user's information
      existingUnverifiedPhone.name = name;
      existingUnverifiedPhone.gender = gender;
      existingUnverifiedPhone.password = hashedPassword;

      // Check if the same email also exists in unverified phone
      const existingUnverifiedEmail = await User.findOne({ email: existingUnverifiedPhone.email });
      if (existingUnverifiedEmail) {
        existingUnverifiedEmail.name = name;
        existingUnverifiedEmail.gender = gender;
        existingUnverifiedEmail.password = hashedPassword;
        await existingUnverifiedEmail.save();
      }

      await existingUnverifiedPhone.save();
      return res.status(200).json({ success: true, message: 'Registration successful' });
    }

    // Create a new user with the provided data and verification code
    const newUser = new User({
      name,
      email,
      phone,
      gender,
      password: hashedPassword,
      verificationCode,
    });

    // Save the user to the database
    await newUser.save();

    res.status(201).json({ success: true, message: 'Registration successful' });
  } catch (error) {
    console.error(error);

    // Handle specific error cases
    if (error.message.includes('validation failed')) {
      return res.status(400).json({ error: 'Invalid input data', details: error.message });
    }

    res.status(500).json({ error: 'Registration failed', details: error.message });
  }
});

module.exports = router;
