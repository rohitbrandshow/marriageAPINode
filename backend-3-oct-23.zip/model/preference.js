const mongoose = require('mongoose');

// Define the schema for BasicDetailsPreference
const basicDetailsPreferenceSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User', // Reference to the User model
    required: true,
    unique: true, // Each user can have only one set of basic details preferences
  },
  ageRange: {
    min: Number, // Minimum age preference
    max: Number, // Maximum age preference
  },
  heightRange: {
    min: Number, // Minimum height preference
    max: Number, // Maximum height preference
  },
  maritalStatus: [String],
});

// Create the BasicDetailsPreference model
const BasicDetailsPreference = mongoose.model('BasicDetailsPreference', basicDetailsPreferenceSchema);

const communityPreferencesSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User', // Reference to the User model
    required: true,
    unique: true,
  },
  religions: [
    {
      type: String, // Religion (e.g., Hinduism, Islam, Christianity, etc.)
    },
  ],
  communities: [
    {
      type: String, // Community (e.g., Brahmin, Sunni, Roman Catholic, etc.)
    },
  ],
  motherTongues: [
    {
      type: String, // Mother Tongue (e.g., English, Hindi, Tamil, etc.)
    },
  ],
});

// Create the CommunityPreferences model
const CommunityPreferences = mongoose.model('CommunityPreferences', communityPreferencesSchema);

const locationPreferenceSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User', // Reference to the User model
    required: true,
    unique: true, // Each user can have only one set of location preferences
  },
  locations: [
    {
      type: String, // Location (e.g., City, State, Country, etc.)
    },
  ],
});
const locationPreference = mongoose.model('locationPreference', locationPreferenceSchema);

const educationCareerPreferenceSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User', // Reference to the User model
    required: true,
    unique: true, // Each user can have only one set of education and career preferences
  },
  qualifications: [
    {
      type: String, // Qualification (e.g., Bachelor's, Master's, Ph.D., etc.)
    },
  ],
  workingWith: [
    {
      type: String, // Company, Self-Employed, Government, Private, etc.
    },
  ],
  professions: [
    {
      type: String, // Profession (e.g., Engineer, Doctor, Teacher, etc.)
    },
  ],
  annualIncome: {
    openToAll: Boolean, // true or false
    currency: String, // Currency (e.g., USD, EUR, INR, etc.)
    incomeFrom: Number, // Minimum income range
    incomeTo: Number, // Maximum income range
  },
});

const educationCareerPreference = mongoose.model('educationCareerPreference', educationCareerPreferenceSchema);

const otherPreferencesSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User', // Reference to the User model
    required: true,
    unique: true, // Each user can have only one set of other preferences
  },
  profileCreatedBy: [
    {
      type: String, // Profile created by (e.g., Self, Parents, Siblings, etc.)
    },
  ],
  diet: [
    {
      type: String, // Diet preference (e.g., Vegetarian, Non-Vegetarian, Vegan, etc.)
    },
  ],
});

const OtherPreferences = mongoose.model('OtherPreferences', otherPreferencesSchema);

module.exports = {
  BasicDetailsPreference,
  CommunityPreferences,
  locationPreference,
  educationCareerPreference,
  OtherPreferences
};
