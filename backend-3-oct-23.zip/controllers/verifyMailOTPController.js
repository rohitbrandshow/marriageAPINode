const User = require('../model/user');

const verifyEmailOTP = async (req, res) => {
  try {
    const { email, OTP } = req.body;

    // Find the user by email
    const user = await User.findOne({ email: email });
    if (!user) {
      return res.status(400).json({ status: 'failed', message: 'Email not found in the database.' });
    }

    // Check if the OTP matches the one stored in the user document
    if (user.verificationCode !== OTP) {
      return res.status(400).json({ status: 'failed', message: 'Email OTP is different.' });
    }

    // Update user's verification status or perform other relevant actions if needed
    user.isEmailVerified = true;
    await user.save();

    // Send a success response
    res.status(200).json({ status: 'success', message: 'Email Verified' });
  } catch (error) {
    console.error('Error verifying email OTP:', error);
    // Send an error response
    res.status(500).json({ status: 'failed', error: 'Email Verification failed' });
  }
};

module.exports = {
  verifyEmailOTP,
};
