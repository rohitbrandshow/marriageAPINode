const axios = require('axios');
const User = require('../model/user'); // Import the User model
const BasicDetailsPreference = require('../model/preference').BasicDetailsPreference; // Import BasicDetailsPreference from the model file
const CommunityPreferences = require('../model/preference').CommunityPreferences; // Import CommunityPreferences from the model file
const LocationPreference = require('../model/preference').locationPreference; // Import CommunityPreferences from the model file
const EducationCareerPreference = require('../model/preference').educationCareerPreference; // Import CommunityPreferences from the model file
const OtherPreferences = require('../model/preference').OtherPreferences; // Import CommunityPreferences from the model file
const { userLogUrl } = require('../config');

// Controller for creating/updating Basic Details Preferences
const createOrUpdateBasicDetailsPreference = async (req, res) => {
  const { userId, ageRange, heightRange, maritalStatus } = req.body;

  try {
    // Validate the incoming data
    if (!userId) {
      return res.status(400).json({ status: 'false', message: 'User ID is required' });
    }

    // Check if the user exists in your database
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ status: 'false', message: 'User not found' });
    }

    // Check if a document with the specified userId exists
    let basicDetailsPreference = await BasicDetailsPreference.findOne({ userId });

    // Determine the action (inserted or updated)
    let action = 'Inserted';

    if (basicDetailsPreference) {
      // Document with userId exists, update it
      basicDetailsPreference.ageRange = ageRange;
      basicDetailsPreference.heightRange = heightRange;
      basicDetailsPreference.maritalStatus = maritalStatus; // Assuming maritalStatus is an array
      action = 'Updated';
    } else {
      // Document with userId does not exist, create a new one
      basicDetailsPreference = new BasicDetailsPreference({ userId, ageRange, heightRange, maritalStatus });
    }

    await basicDetailsPreference.save();

    // Log the action
    const userLogData = {
      userId,
      action,
      createdBy: userId, // Replace with the actual creator ID
      changeType: action === 'Inserted' ? 'Insert' : 'Update',
      changes: action === 'Inserted'
        ? 'User inserted Basic Details preferences.'
        : 'User updated Basic Details preferences.',
    };

    // Send a POST request to the user-log API
    await axios.post(userLogUrl, userLogData);

    return res.json({ status: 'true', message: `Basic Details preferences ${action.toLowerCase()} successfully` });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ status: 'false', message: error.message });
  }
};


const createOrUpdateCommunityPreferences = async (req, res) => {
  const { userId, religions, communities, motherTongues } = req.body;

  try {
    if (!userId) {
      return res.status(400).json({ status: 'false', message: 'User ID is required' });
    }

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ status: 'false', message: 'User not found' });
    }

    let communityPreferences = await CommunityPreferences.findOne({ userId });

    let action = 'Inserted';

    if (communityPreferences) {
      communityPreferences.religions = religions;
      communityPreferences.communities = communities;
      communityPreferences.motherTongues = motherTongues;
      action = 'Updated';
    } else {
      communityPreferences = new CommunityPreferences({
        userId,
        religions,
        communities,
        motherTongues,
      });
    }

    await communityPreferences.save();

    const userLogData = {
      userId,
      action,
      createdBy: userId, // Replace with the actual creator ID
      changeType: action === 'Inserted' ? 'Insert' : 'Update',
      changes: action === 'Inserted'
        ? 'User inserted Community Preferences.'
        : 'User updated Community Preferences.',
    };

    // Send a POST request to the user-log API if needed
    if (userLogUrl) {
      await axios.post(userLogUrl, userLogData);
    }

    return res.json({ status: 'true', message: `Community Preferences ${action.toLowerCase()} successfully` });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ status: 'false', message: error.message });
  }
};


const createOrUpdateLocationPreferences = async (req, res) => {
  const { userId, locations } = req.body;

  try {
    // Validate the incoming data
    if (!userId) {
      return res.status(400).json({ status: 'false', message: 'User ID is required' });
    }

    // Check if the user exists in your database
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ status: 'false', message: 'User not found' });
    }

    // Check if a document with the specified userId exists
    let locationPreferences = await LocationPreference.findOne({ userId });

    // Determine the action (inserted or updated)
    let action = 'Inserted';

    if (locationPreferences) {
      locationPreferences.locations = locations;
      action = 'Updated';
    } else {
      locationPreferences = new LocationPreference({ userId, locations });
    }

    await locationPreferences.save();

    // Log the action
    const userLogData = {
      userId,
      action,
      createdBy: userId, // Replace with the actual creator ID
      changeType: action === 'Inserted' ? 'Insert' : 'Update',
      changes: action === 'Inserted'
        ? 'User inserted Location preferences.'
        : 'User updated Location preferences.',
    };

    // Send a POST request to the user-log API
    await axios.post(userLogUrl, userLogData);

    return res.json({ status: 'true', message: `Location preferences ${action.toLowerCase()} successfully` });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ status: 'false', message: error.message });
  }
};


const createOrUpdateEducationCareerPreferences = async (req, res) => {
  const {
    userId,
    qualifications,
    workingWith,
    professions,
    annualIncome,
  } = req.body;

  try {
    // Validate the incoming data
    if (!userId) {
      return res.status(400).json({ status: 'false', message: 'User ID is required' });
    }

    // Check if the user exists in your database
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ status: 'false', message: 'User not found' });
    }

    // Check if a document with the specified userId exists
    let educationCareerPreferences = await EducationCareerPreference.findOne({ userId });

    // Determine the action (inserted or updated)
    let action = 'Inserted';

    if (educationCareerPreferences) {
      educationCareerPreferences.qualifications = qualifications;
      educationCareerPreferences.workingWith = workingWith;
      educationCareerPreferences.professions = professions;
      educationCareerPreferences.annualIncome = annualIncome;
      action = 'Updated';
    } else {
      educationCareerPreferences = new EducationCareerPreference({
        userId,
        qualifications,
        workingWith,
        professions,
        annualIncome,
      });
    }

    await educationCareerPreferences.save();

    // Log the action
    const userLogData = {
      userId,
      action,
      createdBy: userId, // Replace with the actual creator ID
      changeType: action === 'Inserted' ? 'Insert' : 'Update',
      changes: action === 'Inserted'
        ? 'User inserted Education and Career preferences.'
        : 'User updated Education and Career preferences.',
    };

    // Send a POST request to the user-log API
    await axios.post(userLogUrl, userLogData);

    return res.json({ status: 'true', message: `Education and Career preferences ${action.toLowerCase()} successfully` });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ status: 'false', message: error.message });
  }
};

const createOrUpdateOtherPreferences = async (req, res) => {
  const { userId, profileCreatedBy, diet } = req.body;

  try {
    if (!userId) {
      return res.status(400).json({ status: 'false', message: 'User ID is required' });
    }

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ status: 'false', message: 'User not found' });
    }

    let otherPreferences = await OtherPreferences.findOne({ userId });

    let action = 'Inserted';

    if (otherPreferences) {
      otherPreferences.profileCreatedBy = profileCreatedBy;
      otherPreferences.diet = diet;
      action = 'Updated';
    } else {
      otherPreferences = new OtherPreferences({
        userId,
        profileCreatedBy,
        diet,
      });
    }

    await otherPreferences.save();

    const userLogData = {
      userId,
      action,
      createdBy: userId, // Replace with the actual creator ID
      changeType: action === 'Inserted' ? 'Insert' : 'Update',
      changes: action === 'Inserted'
        ? 'User inserted Other Preferences.'
        : 'User updated Other Preferences.',
    };

    if (userLogUrl) {
      await axios.post(userLogUrl, userLogData);
    }

    return res.json({ status: 'true', message: `Other Preferences ${action.toLowerCase()} successfully` });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ status: 'false', message: error.message });
  }
};


module.exports = {
    createOrUpdateBasicDetailsPreference,
    createOrUpdateCommunityPreferences,
    createOrUpdateLocationPreferences,
    createOrUpdateEducationCareerPreferences,
    createOrUpdateOtherPreferences
};
